/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionrobotsservicio;

import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Luca
 */
public class FlotaRobots {
    private final String nombre;
    private final List<Robot> robots = new ArrayList<>();

    public FlotaRobots(String nombre) {
        this.nombre = Validaciones.textoNoVacio(nombre);
    }
    
    public void agregarRobot(Robot robot){
        Validaciones.noNulo(robot);
        if(robots.contains(robot)){
            throw new RobotDuplicadoException("Robot duplicado.");
        }
        robots.add(robot);
    }
    
    public List<Robot> obtenerRobots(){
        return new ArrayList<>(robots);
    }
    
    public List<Robot> filtrarPorPrioridad(Prioridad prioridad){
        List<Robot> listaFiltrada = new ArrayList<>();
        
        for(Robot robot : robots){
            if (robot.getPrioridad() == prioridad){
                listaFiltrada.add(robot);
            }
        }
        return listaFiltrada;
    }
    
    public List<Robot> obtenerRobotsConConsumoMaximo(double consumo){
        List<Robot> listaFiltrada = new ArrayList<>();
        
        for(Robot robot : robots){
            if (robot.calcularConsumoBateria() == consumo){
                listaFiltrada.add(robot);
            }
        }
        return listaFiltrada;
    }
}
