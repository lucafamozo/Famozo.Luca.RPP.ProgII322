/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gestionrobotsservicio;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Luca
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        FlotaRobots flota = new FlotaRobots("TecnoAsistencia");
        flota.agregarRobot(new RobotLimpieza("RL-10", "Nova", Prioridad.ALTA, 60, 80));
        flota.agregarRobot(new RobotVigilancia("RV-20", "Orbis", Prioridad.MEDIA, 75, 3));
        flota.agregarRobot(new RobotReparto("RR-30", "Nova", Prioridad.BAJA, 40, 5));
        flota.agregarRobot(new RobotReparto("RR-40", "Orbis", Prioridad.ALTA, 15, 4));
        flota.agregarRobot(new RobotVigilancia("RL-10", "Nova", Prioridad.BAJA, 90, 2));
        System.out.println("Robots registrados:");
        mostrarRobots(flota.obtenerRobots());
        System.out.println("\nEjecución de servicios:");
        ejecutarServicios(flota.obtenerRobots());
        System.out.println("\nDiagnósticos:");
        generarDiagnosticos(flota.obtenerRobots());
        System.out.println("\nRobots de prioridad ALTA:");
        mostrarRobots(flota.filtrarPorPrioridad(Prioridad.ALTA));
        System.out.println("\nRobots con consumo máximo de 18:");
        mostrarRobots(flota.obtenerRobotsConConsumoMaximo(18));
        System.out.println("\nConsumos actuales:");
        mostrarConsumos(flota.obtenerRobots());
    }

    private static void mostrarRobots(List<Robot> robots) {
        for (Robot robot : robots){
            System.out.println(robot);
        }
    }

    private static void ejecutarServicios(List<Robot> robots) {
        for(Robot robot : robots){
            if(robot instanceof DaServicio){
               DaServicio ejecutable = (DaServicio) robot;
               try{
                   System.out.println(ejecutable.ejecutarServicio());
               } catch(IllegalStateException e){
                   System.out.println("No se pudo ejecutar.");
               }
            } else{
                System.out.println("El robot no ejecuta servicios.");
            }
        }
    }

    private static void generarDiagnosticos(List<Robot> robots) {
        for(Robot robot : robots){
            if(robot instanceof DaDiagnostico){
               DaDiagnostico ejecutable = (DaDiagnostico) robot;
               try{
                   System.out.println(ejecutable.darDiagnostico());
               } catch(IllegalStateException e){
                   System.out.println("No se pudo diagnosticar.");
               }
            } else{
                System.out.println("El robot no da diagnosticos.");
            }
        }
    }

    private static void mostrarConsumos(List<Robot> robots) {
        for(Robot robot : robots){
            System.out.println(robot.getNumeroSerie() + ": " + robot.calcularConsumoBateria() + " de nivel de batería.");
        }

    }
}
