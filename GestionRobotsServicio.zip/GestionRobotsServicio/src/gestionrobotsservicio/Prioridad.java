/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package gestionrobotsservicio;

/**
 *
 * @author Luca
 */
public enum Prioridad {
    BAJA,
    MEDIA,
    ALTA
}
