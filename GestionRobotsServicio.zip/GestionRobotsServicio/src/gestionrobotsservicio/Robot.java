/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionrobotsservicio;

import java.util.Objects;

/**
 *
 * @author Luca
 */
public abstract class Robot {
    private final String numeroSerie;
    private final String fabricante;
    private final Prioridad prioridad;
    private double nivelBateria;
    private static final int MIN_BATERIA = 0;
    private static final int MAX_BATERIA = 100;

    public Robot(String numeroSerie, String fabricante, Prioridad prioridad, int nivelBateria) {
        this.numeroSerie = Validaciones.textoNoVacio(numeroSerie);
        this.fabricante = Validaciones.textoNoVacio(fabricante);
        this.prioridad = Validaciones.noNulo(prioridad);
        this.nivelBateria = Validaciones.positivo(nivelBateria);
    }

    public String getNumeroSerie() {
        return numeroSerie;
    }

    public String getFabricante() {
        return fabricante;
    }

    public Prioridad getPrioridad() {
        return prioridad;
    }

    public double getNivelBateria() {
        return nivelBateria;
    }

    public static int getMIN_BATERIA() {
        return MIN_BATERIA;
    }

    public static int getMAX_BATERIA() {
        return MAX_BATERIA;
    }

    public abstract double calcularConsumoBateria();
    
    public void descontarBateria(double consumo){
        Validaciones.positivo(consumo);
        if(nivelBateria < consumo){
            throw new IllegalStateException("Batería insuficiente.");
        }
        nivelBateria -= consumo;
    }

    @Override
    public String toString() {
        return "Robot{" + "numeroSerie=" + numeroSerie + ", fabricante=" + fabricante + ", prioridad=" + prioridad + ", nivelBateria=" + nivelBateria + '}';
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 37 * hash + Objects.hashCode(this.numeroSerie);
        hash = 37 * hash + Objects.hashCode(this.fabricante);
        hash = 37 * hash + Objects.hashCode(this.prioridad);
        hash = 37 * hash + (int) (Double.doubleToLongBits(this.nivelBateria) ^ (Double.doubleToLongBits(this.nivelBateria) >>> 32));
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Robot other = (Robot) obj;
        if (Double.doubleToLongBits(this.nivelBateria) != Double.doubleToLongBits(other.nivelBateria)) {
            return false;
        }
        if (!Objects.equals(this.numeroSerie, other.numeroSerie)) {
            return false;
        }
        if (!Objects.equals(this.fabricante, other.fabricante)) {
            return false;
        }
        return this.prioridad == other.prioridad;
    }
    
    
}
