/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionrobotsservicio;

/**
 *
 * @author Luca
 */
public class RobotLimpieza extends Robot implements DaServicio{
    private final double superficieTrabajo;

    public RobotLimpieza(String numeroSerie, String fabricante, Prioridad prioridad, int nivelBateria, double superficieTrabajo) {
        super(numeroSerie, fabricante, prioridad, nivelBateria);
        this.superficieTrabajo = Validaciones.positivo(superficieTrabajo);
    }
    
    @Override
    public double calcularConsumoBateria(){
        return superficieTrabajo / 10 + 5;
    }
    
    @Override
    public String ejecutarServicio(){
        descontarBateria(calcularConsumoBateria());
        return "Servicio ejecutado.";
    }

    @Override
    public String toString() {
        return "RobotLimpieza{" + "superficieTrabajo=" + superficieTrabajo + '}';
    }
    
    
}
