/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionrobotsservicio;

/**
 *
 * @author Luca
 */
public class RobotReparto extends Robot implements DaServicio, DaDiagnostico{
    private final double capacidadCarga;

    public RobotReparto(String numeroSerie, String fabricante, Prioridad prioridad, int nivelBateria, double capacidadCarga) {
        super(numeroSerie, fabricante, prioridad, nivelBateria);
        this.capacidadCarga = Validaciones.positivo(capacidadCarga);
    }
    
    @Override
    public double calcularConsumoBateria(){
        return capacidadCarga * 3 + 4;
    }
    
    @Override
    public String ejecutarServicio(){
        descontarBateria(calcularConsumoBateria());
        return "Servicio ejecutado.";
    }
    
    @Override
    public String darDiagnostico(){
        return "Diagnostico de la capacidad de carga: " + capacidadCarga;
    }

    @Override
    public String toString() {
        return "RobotReparto{" + "capacidadCarga=" + capacidadCarga + '}';
    }
}
