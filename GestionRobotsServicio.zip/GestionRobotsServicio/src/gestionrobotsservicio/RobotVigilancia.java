/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionrobotsservicio;

/**
 *
 * @author Luca
 */
public class RobotVigilancia extends Robot implements DaDiagnostico{
    private final double cantidadCamaras;

    public RobotVigilancia(String numeroSerie, String fabricante, Prioridad prioridad, int nivelBateria, int cantidadCamaras) {
        super(numeroSerie, fabricante, prioridad, nivelBateria);
        this.cantidadCamaras = Validaciones.positivo(cantidadCamaras);
    }
    
    @Override
    public double calcularConsumoBateria(){
        return cantidadCamaras * 4 + 6;
    }
    
    @Override
    public String darDiagnostico(){
        return "Diagnostico de la cantidad de cámaras activas: " + cantidadCamaras;
    }

    @Override
    public String toString() {
        return "RobotVigilancia{" + "cantidadCamaras=" + cantidadCamaras + '}';
    }
}
