/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gestionrobotsservicio;

/**
 *
 * @author Luca
 */
public class Validaciones {
    static String textoNoVacio(String valor) {
        if (valor == null || valor.isBlank()) {
            throw new IllegalArgumentException("No puede ser nulo ni estar en blanco.");
        }
        return valor;
    }

    static <T> T noNulo(T valor) {
        if (valor == null) {
            throw new IllegalArgumentException("No puede ser nulo.");
        }
        return valor;
    }

    static double positivo(double valor) {
        if (!Double.isFinite(valor) || valor <= 0) {
            throw new IllegalArgumentException("Debe ser un número positivo, pero llegó: " + valor);
        }
        return valor;
    }
}
